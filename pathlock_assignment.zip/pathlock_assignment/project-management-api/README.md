# Project Management RESTful API

## Setup Instructions

### Prerequisites
Node.js installed on your machine.
MongoDB (local or cloud instance).

## Steps to Run the Project



### Install Dependencies by following command
npm install

### Set up environment variables:
Create a .env file in the root directory.
Add the following variables:

MONGO_URI=mongodb://localhost:27017/projectManagement
PORT=5000

### Start the server:
npm start
