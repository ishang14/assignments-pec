const Task = require('../models/Task');
const User = require('../models/User');
const { paginate } = require('../utils/pagination');
const { updateProjectStatus } = require('../utils/statusChecker');

// Create a new task
exports.createTask = async (req, res) => {
  try {
    const { projectId, assignedTo } = req.body;

    // Check if the user exists
    const user = await User.findById(assignedTo);
    if (!user) return res.status(404).json({ error: 'User not found' });

    // Check if the user has more than 5 active tasks
    const activeTasks = await Task.countDocuments({ assignedTo, status: { $ne: 'Completed' } });
    if (activeTasks >= 5) return res.status(400).json({ error: 'User cannot have more than 5 active tasks' });

    // Create and save the task
    const task = new Task(req.body);
    await task.save();

    res.status(201).json(task);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Get all tasks (with pagination and filters)
exports.getTasks = async (req, res) => {
  try {
    const { projectId, assignedTo, status, page = 1, limit = 10 } = req.query;

    const filters = {};
    if (projectId) filters.projectId = projectId;
    if (assignedTo) filters.assignedTo = assignedTo;
    if (status) filters.status = status;

    const { skip, limit: paginationLimit } = paginate(page, limit);

    const tasks = await Task.find(filters)
      .populate('projectId', 'name') // Include project name
      .populate('assignedTo', 'name email') // Include user details
      .skip(skip)
      .limit(paginationLimit);

    const total = await Task.countDocuments(filters);

    res.status(200).json({ total, tasks });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get task by ID
exports.getTaskById = async (req, res) => {
  try {
    const task = await Task.findById(req.params.id)
      .populate('projectId', 'name')
      .populate('assignedTo', 'name email');

    if (!task) return res.status(404).json({ error: 'Task not found' });
    res.status(200).json(task);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Update a task
exports.updateTask = async (req, res) => {
  try {
    const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!task) return res.status(404).json({ error: 'Task not found' });

    // If task is updated to "Completed", check project status
    if (req.body.status === 'Completed') {
      await updateProjectStatus(task.projectId);
    }

    res.status(200).json(task);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Delete a task
exports.deleteTask = async (req, res) => {
  try {
    const task = await Task.findByIdAndDelete(req.params.id);
    if (!task) return res.status(404).json({ error: 'Task not found' });
    res.status(200).json({ message: 'Task deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
