// utils/statusChecker.js
const Task = require('../models/Task');
const Project = require('../models/Project');

exports.updateProjectStatus = async (projectId) => {
  try {
    const remainingTasks = await Task.countDocuments({ projectId, status: { $ne: 'Completed' } });

    // Update project status to "Completed" if no tasks are pending
    if (remainingTasks === 0) {
      await Project.findByIdAndUpdate(projectId, { status: 'Completed' });
    }
  } catch (err) {
    console.error('Error updating project status:', err.message);
    throw new Error('Failed to update project status');
  }
};
