// utils/pagination.js
exports.paginate = (query, page = 1, limit = 10) => {
    const skip = (page - 1) * limit;
    const options = {
      skip: parseInt(skip),
      limit: parseInt(limit),
    };
    return options;
  };
  