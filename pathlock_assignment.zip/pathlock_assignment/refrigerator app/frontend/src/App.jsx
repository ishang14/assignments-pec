import React from 'react';
import AddProduct from './components/AddProduct';
import ProductList from './components/ProductList';
import ConsumeProduct from './components/ConsumeProduct';
import ShoppingSuggestions from './components/ShoppingSuggestions';
import ExpiredProducts from './components/ExpiredProducts';

const App = () => {
  return (
    <div className="container">
      <h1>Refrigerator App</h1>

      <div className="product-section">
        <AddProduct />
        <ConsumeProduct />
      </div>

      <ProductList />

      <div className="suggestions-expired">
        <ShoppingSuggestions />
        <ExpiredProducts />
      </div>
    </div>
  );
};

export default App;
