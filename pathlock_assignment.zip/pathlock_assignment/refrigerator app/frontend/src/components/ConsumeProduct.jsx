import React, { useState } from 'react';
import axios from '../axios';

const ConsumeProduct = () => {
  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState('');

  const handleConsume = async (e) => {
    e.preventDefault();

    const consumptionData = { name, quantity: parseInt(quantity) };

    try {
      await axios.post('consume', consumptionData);
      alert('Product consumed successfully!');
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="form-container">
      <h2>Consume Product</h2>
      <form onSubmit={handleConsume}>
        <input
          type="text"
          placeholder="Product Name"
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          type="number"
          placeholder="Quantity"
          onChange={(e) => setQuantity(e.target.value)}
          required
        />
        <button type="submit">Consume Product</button>
      </form>
    </div>
  );
};

export default ConsumeProduct;
