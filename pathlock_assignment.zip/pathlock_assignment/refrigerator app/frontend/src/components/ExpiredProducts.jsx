import React, { useEffect, useState } from 'react';
import axios from '../axios';

const ExpiredProducts = () => {
  const [expired, setExpired] = useState([]);

  // Fetch expired products on component mount and whenever products change
  useEffect(() => {
    const fetchExpired = async () => {
      try {
        const res = await axios.get('expired');
        setExpired(res.data);
      } catch (err) {
        console.error('Error fetching expired products', err);
      }
    };

    fetchExpired();
  }, [expired]); // Ensure re-fetch when expired list changes

  return (
    <div className="expired">
      <h2>Expired Products</h2>
      {expired.length === 0 ? (
        <p>No expired products at the moment.</p>
      ) : (
        <ul>
          {expired.map((product) => (
            <li key={product._id}>
              {product.name} - Expired on{' '}
              {new Date(product.expiration_date).toLocaleDateString()}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default ExpiredProducts;
