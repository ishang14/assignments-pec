import React, { useEffect, useState } from 'react';
import axios from '../axios';

const ProductList = () => {
  const [products, setProducts] = useState([]);

  // Fetch products when the component is mounted and when products change
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await axios.get('/'); // Ensure endpoint is correct
        setProducts(res.data);
      } catch (err) {
        console.error("Error fetching products", err);
      }
    };

    fetchProducts();
  }, [products]); // Dependency on products array ensures refetch after any state change

  return (
    <div className="product-list">
      <h2>Product List</h2>
      {products.length === 0 ? (
        <p>No products available in the refrigerator.</p>
      ) : (
        <ul>
          {products.map((product) => (
            <li key={product._id}>
              {product.name} - {product.quantity} units (Expires on{' '}
              {new Date(product.expiration_date).toLocaleDateString()})
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default ProductList;
