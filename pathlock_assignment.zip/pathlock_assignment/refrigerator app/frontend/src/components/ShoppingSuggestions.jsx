import React, { useEffect, useState } from 'react';
import axios from '../axios';

const ShoppingSuggestions = () => {
  const [suggestions, setSuggestions] = useState([]);

  // Fetch shopping suggestions based on low stock whenever products change
  useEffect(() => {
    const fetchSuggestions = async () => {
      try {
        const res = await axios.get('suggestions');
        setSuggestions(res.data);
      } catch (err) {
        console.error('Error fetching shopping suggestions', err);
      }
    };

    fetchSuggestions();
  }, [suggestions]); // Refetch suggestions when products change

  return (
    <div className="suggestions">
      <h2>Shopping Suggestions</h2>
      {suggestions.length === 0 ? (
        <p>No suggestions at the moment.</p>
      ) : (
        <ul>
          {suggestions.map((product) => (
            <li key={product._id}>
              {product.name} - Low stock, consider restocking!
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default ShoppingSuggestions;
