# For Setting up FRONTEND 
## go inside frontend folder and run following

npm install
npm run dev
it will start running on localhost:5173


# For setting up BACKEND , go inside backend folder and run following
## go inside frontend folder and run following

npm install
npm start