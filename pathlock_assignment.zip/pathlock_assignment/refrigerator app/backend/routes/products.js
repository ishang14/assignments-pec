const express = require('express');
const Product = require('../models/Product');
const router = express.Router();

// Insert new product
router.post('/insert', async (req, res) => {
  const { name, quantity, expiration_date } = req.body;

  try {
    const newProduct = new Product({
      name,
      quantity,
      expiration_date: new Date(expiration_date)
    });
    await newProduct.save();
    res.status(200).json({ message: 'Product added successfully!' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Consume a product
router.post('/consume', async (req, res) => {
  const { name, quantity } = req.body;

  try {
    const product = await Product.findOne({ name });
    if (product) {
      if (product.quantity >= quantity) {
        product.quantity -= quantity;
        await product.save();
        res.status(200).json({ message: 'Product consumed successfully!' });
      } else {
        res.status(400).json({ message: 'Insufficient quantity!' });
      }
    } else {
      res.status(404).json({ message: 'Product not found!' });
    }
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get all products
router.get('/', async (req, res) => {
  try {
    const products = await Product.find();
    res.status(200).json(products);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get expired products
router.get('/expired', async (req, res) => {
  try {
    const expiredProducts = await Product.find({ expiration_date: { $lt: new Date() } });
    res.status(200).json(expiredProducts);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get shopping list suggestions based on low stock
router.get('/suggestions', async (req, res) => {
  try {
    const products = await Product.find();
    const suggestions = products.filter(product => product.quantity <= 1); // Suggest if quantity <= 1
    res.status(200).json(suggestions);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
